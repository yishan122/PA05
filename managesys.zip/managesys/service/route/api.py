from flask import Flask,request
from flask_cors import CORS
from bson import json_util as jsonb
from bson.objectid import ObjectId
from package.connectMongoDB import connect_mongo
import requests
app = Flask('__main__')
CORS(app,supports_credentials=True)
mycol = connect_mongo('test','film')

@app.route('/get-film',methods=['GET'])
def getList():
  str = request.args.get('str')
  if str:
    res = mycol.find({}).sort([(str,1)])
  else:
    res = mycol.find({})
  return jsonb.dumps({"success":True,"data":res})

@app.route('/add-film',methods=['POST'])
def add():
  date_str = eval(request.data)['date']
  description = eval(request.data)['description']
  amount = eval(request.data)['amount']
  category = eval(request.data)['category']
  mycol.insert_one({"date":date_str,"description":description,"amount":amount,"category":category})
  return jsonb.dumps({"success":True})

@app.route('/delete-film',methods=['DELETE'])
def delOne():
  id = eval(request.data)['id']
  mycol.delete_one({"_id":ObjectId(id)})
  return jsonb.dumps({"success":True})

@app.route('/edit-film',methods=['PUT'])
def updateOne():
  id = eval(request.data)['id']
  date_str = eval(request.data)['date']
  description = eval(request.data)['description']
  amount = eval(request.data)['amount']
  category = eval(request.data)['category']
  mycol.update_one({"_id":ObjectId(id)},{"$set":{"date":date_str,"description":description,"amount":amount,"category":category}})
  return jsonb.dumps({"success":True})

@app.route('/get-film-by-category',methods=['GET'])
def getFilmByCategory():
  res = mycol.aggregate([
    {
    '$group': {'_id': '$category', 'amount': {'$sum': '$amount'}}
    }
  ])
  return jsonb.dumps({"success":True,"data":res})
