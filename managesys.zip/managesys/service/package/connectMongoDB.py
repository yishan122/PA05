from pymongo import MongoClient
def connect_mongo(database,document):
  client = MongoClient('127.0.0.1',27017)
  db = client[database]
  collection = db[document]
  return collection