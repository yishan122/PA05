import React,{useState,useEffect} from 'react';
import { DeleteOutlined,EditOutlined  } from '@ant-design/icons';
import { Button, Form, Input,message, Space,Table,Modal,DatePicker,InputNumber,Popconfirm } from 'antd';
import { useNavigate } from 'react-router-dom';
import {addFilm,getFilm,deleteFilm,editFilm} from '@/api'
import './index.scss';
import dayjs from 'dayjs'
const Transaction = ()=>{
const navigate = useNavigate()
const [tableData,setTableData] = useState([])
const [isModalOpen,setModalOpen] = useState(false)
const [id,setId] = useState('')
const [form] = Form.useForm();
const getFilmList = async (str)=>{
    const res = await getFilm({str})
    if(res.success){
      setTableData(res.data)
    }
}
  const columns = [
    {
      title:'description',
      dataIndex:'description',
      key:'dec'
    },
    {
      title:'amount',
      dataIndex:'amount',
      key:'damountc'
    },
    {
      title:'category',
      dataIndex:'category',
      key:'category'
    },
    {
      title:'date',
      dataIndex:'date',
      key:'date'
    },
    {
      title:'delete',
      key:'del',
      render:(row)=><Popconfirm
      title="Delete the item"
      description="Are you sure to delete this item?"
      onConfirm={async ()=>{
        const res = await deleteFilm({id:row._id.$oid})
        if(res.success){
          message.success('delete successfully')
          getFilmList()
        }
      }}
      onCancel={()=>{message.info('already cancelled')}}
      okText="Yes"
      cancelText="No"
    >
      <Button type='link'><DeleteOutlined /></Button>
    </Popconfirm>
    },
    {
      title:'edit',
      key:'edit',
      render:(row)=> (<Button type='link'>
        <EditOutlined onClick={()=>{
        setModalOpen(true)
        setId(row._id.$oid)
        const {description,amount,category,date} = row
        form.setFieldsValue({
          description,
          amount,
          category,
          date:dayjs(date)
        })
      }} />
      </Button>)
    }
  ]
  useEffect(()=>{
    getFilmList()
  },[])
  return (
    <div className='transaction'>
      <div className='button-wrapper'>
        <Space>
          <Button onClick={()=>{navigate('/transaction/byCategory')}} type='primary'>group by category</Button>
          <Button onClick={()=>{getFilmList('category')}} type='primary'>sort by category</Button>
          <Button onClick={()=>{getFilmList('amount')}} type='primary'>sort by amount</Button>
          <Button onClick={()=>{getFilmList('description')}} type='primary'>sort by description</Button>
          <Button onClick={()=>{getFilmList('date')}} type='primary'>sort by date</Button>
        </Space>
        <Button type='primary'onClick={()=>{setModalOpen(true)}}>create</Button>
      </div>
      <Table rowKey={record=>record._id.$oid} bordered columns={columns} dataSource={tableData} />
      <Modal
       title={id?"Edit":"Create"}
        open={isModalOpen}
        footer={null}
        onCancel={()=>setModalOpen(false)}
        maskClosable={false}>
      <Form
        form={form}
        name="basic"
        labelCol={{
          span: 8,
        }}
        wrapperCol={{
          span: 16,
        }}
        style={{
          maxWidth: 600,
        }}
        initialValues={{
          remember: true,
        }}
        onFinish={async (v)=>{
          const {description,amount,category,date} = v
          if(!!id){
            const res = await editFilm({
              id,
              description,
              amount,
              category,
              date:dayjs(date).format("YYYY-MM-DD")})
              if(res.success){
                message.success('edit successfully')
                setModalOpen(false)
                getFilmList()
                form.resetFields()
                setId('')
              }
            return
          }
            const res = await addFilm({
              description,
              amount,
              category,
              date:dayjs(date).format("YYYY-MM-DD")
            })
            if(res.success){
              message.success('created successfully')
              setModalOpen(false)
              getFilmList()
              form.resetFields()
            }
        }}
        onFinishFailed={()=>{}}
        autoComplete="off"
      >
        <Form.Item
          label="description"
          name="description"
          rules={[
            {
              required: true,
              message: 'Please input description!',
            },
          ]}
        >
          <Input placeholder='description' />
        </Form.Item>

        <Form.Item
          label="category"
          name="category"
          rules={[
            {
              required: true,
              message: 'Please input category!',
            },
          ]}
        >
          <Input placeholder='category' />
        </Form.Item>

        <Form.Item
          name="amount"
          label='amount'
          rules={[
            {
              required: true,
              message: 'Please input amount!',
            },
          ]}
        >
          <InputNumber placeholder='amount' />
        </Form.Item>

        <Form.Item
         label='date'
         name='date'
         rules={[
          {
            required: true,
            message: 'Please input date!',
          },
        ]}
        >
           <DatePicker onChange={(v)=>{
            }} format={'YYYY-MM-DD'} />
        </Form.Item>
        <Form.Item wrapperCol={{ xs: { span: 24, offset: 0 }, sm: { span: 16, offset: 8 } }}>
          <Space>
          <Button type="primary" htmlType="submit">
            Store
          </Button>
          <Button onClick={()=>{ form.resetFields();setModalOpen(false)}} type="primary">
            Cancel
          </Button>
      </Space>
    </Form.Item>
      </Form>
      </Modal>
    </div>)}

export default Transaction