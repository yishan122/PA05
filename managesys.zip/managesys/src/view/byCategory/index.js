import {useState,useEffect} from 'react';
import { Button,Table } from 'antd';
import { useNavigate } from 'react-router-dom';
import {getFilmByCategory} from '@/api'
import './index.scss'

const ByCategory = () => {
  const navigate = useNavigate()
  const [tableData,setTableDate] = useState([])
  const getDataList = async ()=>{
    const res = await getFilmByCategory()
    if(res.success){
      setTableDate(res.data)
    }
  }
  const columns = [
    {
      title:'category',
      dataIndex:'_id',
      key:'_id'
    },
    {
      title:'amount',
      dataIndex:'amount',
      key:'amount'
    }
  ]
  
  useEffect(()=>{
    getDataList()
  },[])
  return (
    <div className='by-category'>
      <div className='btn-wrapper'><Button onClick={()=>{navigate('/transaction')}} type='link'>transaction table</Button></div>
      <Table rowKey={record=>record._id} bordered columns={columns} dataSource={tableData} />
    </div>
  )
};
export default ByCategory;