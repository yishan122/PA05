import axios from 'axios';
import {message} from 'antd'
const {location} = window
const service = axios.create({
  baseURL:process.env.NODE_ENV==='development'?`${location.protocol}//${location.hostname}:3006`:'',
  timeout:'5000'
})
service.interceptors.request.use(
  config=>{
    
    return config
  },
  error=>{
    return Promise.reject(error)
  }
)

service.interceptors.response.use(
  response=>{
    if(response.status === 200){
      return Promise.resolve(response.data) 
    }
  },
  error=>{
    message.error('network error')
    return Promise.reject(error)
  }
)

export const get = (url,params)=>{
  return service.get(url,{params})
}

export const post = (url,data)=>{
  return service.post(url,data)
}

export const deleteApi = (url,data)=>{
  return service.delete(url,{data})
}

export const update = (url,data)=>{
  return service.put(url,data)
}