import React,{useEffect} from 'react';
import {Routes, Route} from 'react-router-dom';
import {Layout,theme } from 'antd';
import routes from './route/index.js';
import 'antd/dist/reset.css';
import './App.scss';
const { Header, Content } = Layout;
const App = () => {
  const {token: { colorBgContainer }} = theme.useToken(); 
  useEffect(()=>{
  },[])
    return (
      <Layout>
        <Header className="app-header">
          <div className="logo">System Manage</div>
        </Header>
        <Layout> 
          <Layout style={{ padding: '0 24px 24px',maxHeight:'calc(100vh - 64px)',overflow:'hidden' }}>
            <Content
              style={{
                padding: 24,
                margin: 0,
                minHeight: 280,
                maxHeight:'calc(100% - 22px)',
                overflowY:'auto',
                background: colorBgContainer,
              }}>
              <Routes>
                {routes.map(item => {
                  return <Route exact path={item.path} element={<item.element />} key={item.path} />
                }
                )}
              </Routes>
            </Content>
          </Layout>
        </Layout>
      </Layout>
    );
  
};


export default App;
