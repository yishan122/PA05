import {get,post,deleteApi,update} from '../utils/request'

export const getFilm = (params)=>get('/get-film',params)

export const addFilm = (data)=>post('/add-film',data)

export const deleteFilm = (data)=>deleteApi('/delete-film',data)

export const editFilm = (data)=>update('/edit-film',data)

export const getFilmByCategory = ()=>get('/get-film-by-category')