import Login from '@/view/transaction';
import Register from '@/view/byCategory';
const routes=[
  {
    path:'/',
    element:Login,
    hidden:true,
    key:'transaction',
    label:'transaction'
  },
  {
    path:'/transaction',
    element:Login,
    hidden:true,
    key:'transaction',
    label:'transaction'
  },
  {
    path:'/transaction/byCategory',
    element: Register,
    hidden: true,
    key:'byCategory',
    label:'byCategory'
  }
]

export default routes